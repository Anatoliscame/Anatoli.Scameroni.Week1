﻿using Spesa_Test.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spesa_Test.Interface
{
    internal interface IGestioneProdotti : IRepository<Prodotto>
    {
        //List<Prodotto> GetProdottiConScadenzaOggi();
        public abstract List<Prodotto> GetAll();

        public abstract bool Aggiungi(Prodotto item);
      //  public abstract T GetByCodice(string codice);

    }
}
