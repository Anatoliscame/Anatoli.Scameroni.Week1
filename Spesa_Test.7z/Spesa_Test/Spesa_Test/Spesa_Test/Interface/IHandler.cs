﻿using Spesa_Test.Handler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spesa_Test
{
    internal interface IHandler
    {
        string HandleRequest(Employee employee);
        IHandler SetNext(IHandler presenzaHandler);
    }
}
