﻿
using Spesa_Test.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spesa_Test.Repository
{
    internal class RepositoryProdottoFile : IGestioneProdotti
    {
        string path = @"C:\Users\Anatoli\source\repos\Spesa_Test\Spesa_Test\Spesa_Test\Spese.txt";

    

        public bool Aggiungi(Prodotto item)
        {
            using (StreamWriter sw = new StreamWriter(path, true))
            {

                sw.WriteLine($"{item.Data_s} - {item.Categoria} - {item.Descrizione} - {item.Importo}");
            }
            return true;
        }



        public List<Prodotto> GetAll()
        {
            List<Prodotto> prodotti = new List<Prodotto>();
            using (StreamReader sr = new StreamReader(path))
            {
                string contenutoFile = sr.ReadToEnd();

                if (string.IsNullOrEmpty(contenutoFile))
                {
                    return prodotti;
                }
                else
                {
                    var righeDelFile = contenutoFile.Split("\r\n");
                    for (int i = 0; i < righeDelFile.Length - 1; i++)
                    {
                        var campiDellaRiga = righeDelFile[i].Split(" - ");
                        Prodotto p = new Prodotto();
                        p.Data_s = DateTime.Parse(campiDellaRiga[0]);
                        p.Categoria = campiDellaRiga[1];
                        p.Descrizione = campiDellaRiga[2];
                        p.Importo = double.Parse(campiDellaRiga[3]);

                        prodotti.Add(p);
                    }
                }
                return prodotti;
            }
        }
    }
}
