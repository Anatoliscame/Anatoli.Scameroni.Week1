﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spesa_Test
{
    internal class Prodotto
    {
        public DateTime Data_s { get; set; }
        public string Categoria { get; set; }
        public string Descrizione { get; set; }
        public double Importo { get; set; }

        public Prodotto() { }

        public Prodotto(DateTime d, string categoria, string descr, double imp)
        {
            Data_s = d;
            Categoria = categoria;
            Descrizione = descr;
            Importo = imp;

        }
        public  string Disegna()
        {
            return $"Data = {Data_s}, Categoria = {Categoria}, Descrizione = {Descrizione}, Importo = {Importo}";
        }
    }
}
